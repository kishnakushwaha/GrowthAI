// coderAgent.js
// REPLACES the old generateWebsiteContent() function in smartBuilder.js
//
// WHAT CHANGED AND WHY:
// 1. Model updated: gemini-1.5-flash (deprecated) -> gemini-2.5-flash
// 2. ONE call generating 5 files -> 5 SEPARATE small calls, one per file
//    - Each call only has to hold ONE file's structure in its "head"
//    - A truncation/failure in about.astro no longer kills index.astro
// 3. Added maxOutputTokens cap per call (prevents runaway generation)
// 4. Added retry-with-backoff per file (not per whole pipeline)
// 5. Added output validation (checks the file isn't empty/truncated) before accepting it
// 6. Files are generated in PARALLEL (Promise.all) since they're independent calls
//    -> total wall-clock time often ends up FASTER than the old single big call

import fetch from 'node-fetch';

const MODEL = 'gemini-2.5-flash'; // was: gemini-1.5-flash (deprecated, causes 404s)
const MAX_RETRIES = 2;

/**
 * Calls Gemini with a prompt, returns raw text. Retries on failure.
 */
async function callGemini(prompt, apiKey, maxOutputTokens = 2000) {
  let lastError;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              maxOutputTokens, // hard cap — prevents one file from eating the whole budget
              temperature: 0.7,
            },
          }),
        }
      );

      if (!response.ok) {
        const errBody = await response.text();
        throw new Error(`Gemini API ${response.status}: ${errBody}`);
      }

      const data = await response.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!text || text.trim().length < 20) {
        throw new Error('Empty or suspiciously short response from model');
      }

      return text;
    } catch (err) {
      lastError = err;
      console.warn(`[CoderAgent] ⚠️ Attempt ${attempt}/${MAX_RETRIES} failed: ${err.message}`);
      if (attempt < MAX_RETRIES) {
        await new Promise((r) => setTimeout(r, 1000 * attempt)); // backoff: 1s, 2s
      }
    }
  }
  throw lastError;
}

/**
 * Strips markdown code fences if the model wraps output in ```astro ... ```
 */
function stripCodeFences(text) {
  return text
    .replace(/^```[a-zA-Z]*\n/, '')
    .replace(/```\s*$/, '')
    .trim();
}

/**
 * Basic sanity check that a generated file isn't garbage/truncated.
 * Cheap heuristic, not a full parser — just catches the obvious failure modes.
 */
function isValidAstroFile(content, filePath) {
  if (!content || content.length < 30) return false;
  // Every Astro file in this project should have a frontmatter fence
  if (!content.includes('---')) return false;
  // Layout/pages should reference the Layout import or BE the layout
  if (filePath !== 'src/layouts/Layout.astro' && !content.includes('Layout')) return false;
  return true;
}

/**
 * Generates ONE file. Used for all 5 files via Promise.all below.
 */
async function generateSingleFile({ filePath, instructions, strategy, copy, images, lead }, apiKey) {
  const prompt = `
You are a Senior Astro + React engineer. Generate EXACTLY ONE file. Output ONLY the raw file content — no markdown fences, no explanation, no XML tags.

FILE TO GENERATE: ${filePath}

CONTEXT:
- Business: ${lead.businessName} (${lead.industry})
- Theme: primary=${strategy.tailwindPrimaryColor}, bg=${strategy.tailwindBgColor}
- Heading font: ${strategy.fontFamilyHeading}, Body font: ${strategy.fontFamilyBody}
- Selected components: ${JSON.stringify(strategy.componentSelection)}
- Images available: ${JSON.stringify(images)}
- Copy to use: ${JSON.stringify(copy)}
- Reviews (use EXACT quotes if this is the homepage): ${JSON.stringify(lead.reviews)}

SPECIFIC INSTRUCTIONS FOR THIS FILE:
${instructions}

RULES:
- Output ONLY valid Astro file content, nothing else.
- Internal links MUST use: href={import.meta.env.BASE_URL + "about"}
- Dark theme: bg-zinc-950 text-zinc-100 or similar based on strategy.
- Keep it tight and valid — this is ONE file, not five.
`.trim();

  const raw = await callGemini(prompt, apiKey, 1500); // 1500 tokens is plenty for ONE file
  const content = stripCodeFences(raw);

  if (!isValidAstroFile(content, filePath)) {
    throw new Error(`Validation failed for ${filePath} — output looked malformed or truncated`);
  }

  return { filePath, content };
}

/**
 * Main export — replaces generateWebsiteContent().
 * Generates all 5 files IN PARALLEL, each as its own small, retryable, validated call.
 */
export async function generateWebsiteContent(lead, strategy, copy, images, apiKey) {
  console.log(`[CoderAgent] 🧑‍💻 Generating 5 files as separate parallel calls...`);

  const fileJobs = [
    {
      filePath: 'src/layouts/Layout.astro',
      instructions: `Must include Google Fonts link (${strategy.fontLink}), import '../styles/global.css' in frontmatter, and a sticky <nav> with links to Home/About/Services/Contact using the BASE_URL pattern.`,
    },
    {
      filePath: 'src/pages/index.astro',
      instructions: `Import and use the Hero component (${strategy.componentSelection.hero}) and Reviews component (${strategy.componentSelection.reviews}). Map lead reviews' author_name to "author" prop. Wrap in <Layout title="Home">.`,
    },
    {
      filePath: 'src/pages/about.astro',
      instructions: `A text-heavy About page using the "about" copy (headline, story, mission). Wrap in <Layout title="About">.`,
    },
    {
      filePath: 'src/pages/services.astro',
      instructions: `Import and use the Services component (${strategy.componentSelection.services}) with the services copy array. Wrap in <Layout title="Services">.`,
    },
    {
      filePath: 'src/pages/contact.astro',
      instructions: `Import and use the Contact component (${strategy.componentSelection.contact}) with phone, address, and tagline. Wrap in <Layout title="Contact">.`,
    },
  ];

  // Fire all 5 calls in parallel — independent, so failures don't cascade
  const results = await Promise.allSettled(
    fileJobs.map((job) =>
      generateSingleFile({ ...job, strategy, copy, images, lead }, apiKey)
    )
  );

  const files = {};
  const failures = [];

  results.forEach((result, i) => {
    if (result.status === 'fulfilled') {
      files[result.value.filePath] = result.value.content;
      console.log(`[CoderAgent] ✅ ${result.value.filePath}`);
    } else {
      failures.push({ filePath: fileJobs[i].filePath, error: result.reason.message });
      console.error(`[CoderAgent] ❌ ${fileJobs[i].filePath}: ${result.reason.message}`);
    }
  });

  if (failures.length > 0) {
    throw new Error(
      `${failures.length}/5 files failed to generate: ${failures.map((f) => f.filePath).join(', ')}`
    );
  }

  console.log(`[CoderAgent] ✅ All 5 files generated and validated.`);
  return files;
}
